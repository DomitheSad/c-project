# Project

Αρχικό scaffold για την εργασία C++.

Quick start

- Build with CMake (Windows):

```powershell
mkdir build; cd build; cmake ..; cmake --build . --config Release
```

- Run:

```powershell
.\build\Release\project.exe
```

Περιεχόμενα

- `src/` : κώδικας
- `include/` : headers
- `tests/` : unit tests (απλό harness)
- `docs/requirements.md` : χώρος για τις απαιτήσεις (συνοψίσεις)

Επόμενα βήματα: συμπλήρωση `docs/requirements.md` από το `ΕκφώνησηΕργασίας2025-26.pdf` και υλοποίηση MVP.