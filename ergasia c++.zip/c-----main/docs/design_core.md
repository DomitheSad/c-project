# GridWorld — Core Design

Part A (Core & Pathfinding)

- `Map`:
  - Loads `maps/*.json` with `width`, `height`, and `grid` array (strings of '.' and '#').
  - API: `isFree(Point)`, `neighbors(Point)`, `width()`, `height()`.

- `AStar`:
  - `std::optional<Path> findPath(const Map&, Point start, Point goal)`.
  - Uses Manhattan heuristic, 4-way movement.

- Types: `Point {int x,y}`, `Path = vector<Point>`.

Unit tests:
- Pathfinding tests for simple scenarios.

Notes:
- The scaffold uses a crude parser for `maps/*.json`; replace with a JSON library in Part A implementation if desired.
