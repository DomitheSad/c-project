#pragma once

#include <memory>
#include <vector>

#include "../core/Map.h"
#include "Entity.h"

namespace grid {

struct GlobalState {
    Map map;

    int tick_delay_ms = 150;
    float accumulator_ms = 0.0f;

    bool paused = false;
    bool step_once = false;

    int selected_agent_id = -1;

    int autopilot_agent_id = -1;

    int targets_total = 0;
    int targets_collected = 0;

    int match_duration_sec = 120;
    float match_time_left_ms = 120000.0f;
    bool match_started = false;
    bool match_over = false;

    int player1_agent_id = -1; 
    int player2_agent_id = -1; 

    int cpu_agent_id = -1;

    
    int cpu_difficulty = 1;

    
    std::vector<std::unique_ptr<Entity>> entities;
};

} // namespace grid
