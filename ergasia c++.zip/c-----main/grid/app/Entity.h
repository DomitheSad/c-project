#pragma once

namespace grid {

struct GlobalState;

class Entity {
public:
    virtual ~Entity() = default;

    // s false when the entity isdespawned
    virtual bool update(GlobalState& state, float dt_ms) = 0;
    virtual void draw(const GlobalState& state) const = 0;
};

} 
