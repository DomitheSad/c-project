from __future__ import annotations

import re
import sys
from pathlib import Path

from pypdf import PdfReader


def _snippets(text: str, pattern: str, context: int = 250, limit: int = 6) -> list[str]:
    out: list[str] = []
    for m in re.finditer(pattern, text, flags=re.IGNORECASE):
        start = max(0, m.start() - context)
        end = min(len(text), m.end() + context)
        snippet = text[start:end]
        snippet = re.sub(r"\s+", " ", snippet).strip()
        out.append(snippet)
        if len(out) >= limit:
            break
    return out


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: extract_assignment_pdf.py <path-to-pdf> [out-file]", file=sys.stderr)
        return 2

    pdf_path = Path(sys.argv[1]).expanduser()
    if not pdf_path.exists():
        print(f"PDF not found: {pdf_path}", file=sys.stderr)
        return 2

    out_path = Path(sys.argv[2]) if len(sys.argv) >= 3 else Path(__file__).resolve().parents[1] / "docs" / "assignment_extracted_snippets.txt"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    reader = PdfReader(str(pdf_path))
    pages_text: list[str] = []
    for i, page in enumerate(reader.pages):
        try:
            pages_text.append(page.extract_text() or "")
        except Exception:
            pages_text.append("")

    text = "\n\n".join(pages_text)

    keywords = {
        "sgg": r"\bsgg\b|simple game graphics",
        "graphics": r"γραφικ|graphics|window|παραθυρ",
        "pathfinding": r"A\*|AStar|pathfinding|αναζ\w*τηση|διαδρομ",
        "tests": r"test|unit test|τεστ|δοκιμ\w*|μονάδ\w*",
        "deliverables": r"παραδο\w*|deliverable|παράδο\w*",
        "grading": r"κριτηρ\w*|αξιολογ\w*|βαθμ",
        "maps": r"maps\b|\.json|json|χαρτ\w*",
        "dynamic_memory": r"δυναμ\w*\s+μνήμ\w*|\bnew\b|\bdelete\b|unique_ptr|shared_ptr",
        "oop": r"κληρονομ\w*|πολυμορφ\w*|virtual|override|abstract|ιεραρχ\w*",
        "stl": r"\bSTL\b|vector|map|unordered_map|set|list|queue|stack|hash",
        "deadline": r"προθεσμ\w*|deadline|ημερ\w*",
    }

    lines: list[str] = []
    lines.append(f"PDF: {pdf_path}")
    lines.append(f"Pages: {len(reader.pages)}")
    lines.append(f"Extracted chars: {len(text)}")
    lines.append("")

    for name, pat in keywords.items():
        found = re.search(pat, text, flags=re.IGNORECASE) is not None
        lines.append(f"[{name}] found: {found}")
    lines.append("")

    for name, pat in keywords.items():
        snips = _snippets(text, pat, context=260, limit=4)
        if not snips:
            continue
        lines.append(f"==== SNIPPETS: {name} ====")
        for s in snips:
            lines.append(f"- {s}")
        lines.append("")

    # Also include broader context slices (start/middle/end)
    def _slice(label: str, start: int, end: int) -> None:
        chunk = re.sub(r"\s+", " ", text[start:end]).strip()
        lines.append(f"==== {label} ====")
        lines.append(chunk)
        lines.append("")

    _slice("DOC START (first ~3500 chars)", 0, min(len(text), 3500))

    mid = max(0, len(text) // 2 - 1750)
    _slice("DOC MIDDLE (around midpoint, ~3500 chars)", mid, min(len(text), mid + 3500))

    tail_start = max(0, len(text) - 3500)
    _slice("DOC END (last ~3500 chars)", tail_start, len(text))

    out_path.write_text("\n".join(lines), encoding="utf-8")

    print(f"Wrote: {out_path}")
    # print the key part to terminal too
    print("\n".join(lines[:30]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
