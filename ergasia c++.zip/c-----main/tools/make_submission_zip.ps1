param(
  [Parameter(Mandatory = $true)]
  [string]$ZipName,

  [string]$StagingDir = "submission_staging"
)

$ErrorActionPreference = "Stop"

function Copy-TreeFiltered {
  param(
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Dest,
    [string[]]$Exclude = @()
  )

  if (!(Test-Path -LiteralPath $Source)) {
    Write-Host "Skip (missing): $Source"
    return
  }

  New-Item -ItemType Directory -Force -Path $Dest | Out-Null

  $args = @(
    "`"$Source`"",
    "`"$Dest`"",
    "/E",
    "/NFL", "/NDL", "/NJH", "/NJS", "/NP",
    "/R:1", "/W:1"
  )

  foreach ($ex in $Exclude) {
    $args += @("/XD", $ex)
    $args += @("/XF", $ex)
  }

  $null = & robocopy @args
  # robocopy uses bitmask exit codes; 0-7 are success-ish
  if ($LASTEXITCODE -gt 7) {
    throw "robocopy failed for $Source -> $Dest (code $LASTEXITCODE)"
  }
}

$root = (Resolve-Path -LiteralPath $PSScriptRoot\..).Path
Set-Location -LiteralPath $root

$staging = Join-Path $root $StagingDir
if (Test-Path -LiteralPath $staging) {
  Remove-Item -LiteralPath $staging -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $staging | Out-Null

# Copy project sources/assets/docs (no build artifacts)
Copy-Item -LiteralPath (Join-Path $root "CMakeLists.txt") -Destination $staging -Force
Copy-Item -LiteralPath (Join-Path $root "README.md") -Destination $staging -Force

Copy-TreeFiltered -Source (Join-Path $root "docs")     -Dest (Join-Path $staging "docs")
Copy-TreeFiltered -Source (Join-Path $root "grid")     -Dest (Join-Path $staging "grid")
Copy-TreeFiltered -Source (Join-Path $root "include")  -Dest (Join-Path $staging "include")
Copy-TreeFiltered -Source (Join-Path $root "src")      -Dest (Join-Path $staging "src")
Copy-TreeFiltered -Source (Join-Path $root "examples") -Dest (Join-Path $staging "examples")
Copy-TreeFiltered -Source (Join-Path $root "configs")  -Dest (Join-Path $staging "configs")
Copy-TreeFiltered -Source (Join-Path $root "maps")     -Dest (Join-Path $staging "maps")

if (Test-Path -LiteralPath (Join-Path $root "assets")) {
  Copy-TreeFiltered -Source (Join-Path $root "assets") -Dest (Join-Path $staging "assets")
}

# Copy ONLY the required SGG headers into ./sgg (as per assignment instructions)
$sggSrc = Join-Path $root "sgg-main\sgg"
$sggDst = Join-Path $staging "sgg"
New-Item -ItemType Directory -Force -Path $sggDst | Out-Null

$graphicsH = Join-Path $sggSrc "graphics.h"
$scancodesH = Join-Path $sggSrc "scancodes.h"
if (!(Test-Path -LiteralPath $graphicsH) -or !(Test-Path -LiteralPath $scancodesH)) {
  throw "SGG headers not found at $sggSrc. Expected graphics.h and scancodes.h."
}
Copy-Item -LiteralPath $graphicsH -Destination (Join-Path $sggDst "graphics.h") -Force
Copy-Item -LiteralPath $scancodesH -Destination (Join-Path $sggDst "scancodes.h") -Force

# Remove common junk if it somehow got copied
$junkPatterns = @(
  "*.pdb", "*.obj", "*.ilk", "*.idb", "*.ipch", "*.tlog", "*.pch",
  "*.exe", "*.dll",
  ".vs", "CMakeFiles", "build", "build_*", "out"
)

Get-ChildItem -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue |
  Where-Object {
    $_.PSIsContainer -and ($junkPatterns -contains $_.Name)
  } |
  ForEach-Object {
    try { Remove-Item -LiteralPath $_.FullName -Recurse -Force } catch {}
  }

Get-ChildItem -LiteralPath $staging -Recurse -Force -File -ErrorAction SilentlyContinue |
  Where-Object {
    $name = $_.Name
    $name -like "*.pdb" -or $name -like "*.obj" -or $name -like "*.ilk" -or $name -like "*.idb" -or
    $name -like "*.exe" -or $name -like "*.dll"
  } |
  ForEach-Object {
    try { Remove-Item -LiteralPath $_.FullName -Force } catch {}
  }

$zipPath = Join-Path $root $ZipName
if (!( $zipPath.ToLower().EndsWith(".zip") )) {
  $zipPath = $zipPath + ".zip"
}

if (Test-Path -LiteralPath $zipPath) {
  Remove-Item -LiteralPath $zipPath -Force
}

Compress-Archive -Path (Join-Path $staging "*") -DestinationPath $zipPath -Force

Write-Host "Staged: $staging"
Write-Host "Wrote:  $zipPath"
