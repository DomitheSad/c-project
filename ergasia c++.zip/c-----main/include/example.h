#pragma once
#include <string>

class Example {
public:
    Example() = default;
    std::string greet() const;
};
