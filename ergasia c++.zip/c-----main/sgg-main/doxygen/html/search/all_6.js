var searchData=
[
  ['example_0',['A Simple Example',['../page_simple_app.html',1,'']]]
];
