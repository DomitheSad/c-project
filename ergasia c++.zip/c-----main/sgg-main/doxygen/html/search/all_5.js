var searchData=
[
  ['dependencies_20and_20third_20party_20libraries_0',['Dependencies and Third - Party Libraries',['../index.html#sub_dependencies',1,'']]],
  ['disclaimer_20and_20licensing_1',['Disclaimer and Licensing',['../index.html#sub_licensing',1,'']]]
];
