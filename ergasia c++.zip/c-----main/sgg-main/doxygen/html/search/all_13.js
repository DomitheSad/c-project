var searchData=
[
  ['window_20setup_0',['Window Setup',['../page_simple_app.html#sub_window_setup',1,'']]],
  ['windows_20visual_20studio_202019_1',['Windows (Visual Studio 2019)',['../page_building_with_sgg.html#using_sgg_windows',1,'']]],
  ['windows_20visual_20studio_202019_20msvc_2',['Windows (Visual Studio 2019 - MSVC)',['../page_building_sgg.html#building_sgg_windows_msvc',1,'']]],
  ['with_20sgg_3',['Building your Project with SGG',['../page_building_with_sgg.html',1,'']]],
  ['with_20vcpkg_4',['CMake (with Vcpkg)',['../page_building_sgg.html#building_sgg_cmake',1,'']]],
  ['with_20vcpkg_20toolchain_20and_20no_20registry_20support_5',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['with_20vcpkg_20toolchain_20and_20registry_20support_6',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]]
];
