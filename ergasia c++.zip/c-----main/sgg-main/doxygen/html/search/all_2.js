var searchData=
[
  ['a_20simple_20example_0',['A Simple Example',['../page_simple_app.html',1,'']]],
  ['a_20visual_20studio_20project_20that_20uses_20sgg_1',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]],
  ['an_20application_20that_20uses_20sgg_20from_20the_20command_20line_2',['Compiling an application that uses SGG from the command line',['../page_building_with_sgg.html#using_sgg_windows_cmd',1,'']]],
  ['and_20licensing_3',['Disclaimer and Licensing',['../index.html#sub_licensing',1,'']]],
  ['and_20no_20registry_20support_4',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['and_20registry_20support_5',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]],
  ['and_20third_20party_20libraries_6',['Dependencies and Third - Party Libraries',['../index.html#sub_dependencies',1,'']]],
  ['application_20that_20uses_20sgg_20from_20the_20command_20line_7',['Compiling an application that uses SGG from the command line',['../page_building_with_sgg.html#using_sgg_windows_cmd',1,'']]]
];
