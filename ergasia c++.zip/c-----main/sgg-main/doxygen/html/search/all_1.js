var searchData=
[
  ['2_20configuring_20project_20with_20vcpkg_20toolchain_20and_20no_20registry_20support_0',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['2019_1',['Windows (Visual Studio 2019)',['../page_building_with_sgg.html#using_sgg_windows',1,'']]],
  ['2019_20msvc_2',['Windows (Visual Studio 2019 - MSVC)',['../page_building_sgg.html#building_sgg_windows_msvc',1,'']]]
];
