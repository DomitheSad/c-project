var searchData=
[
  ['msvc_0',['Windows (Visual Studio 2019 - MSVC)',['../page_building_sgg.html#building_sgg_windows_msvc',1,'']]]
];
