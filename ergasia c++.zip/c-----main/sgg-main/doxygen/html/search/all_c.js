var searchData=
[
  ['option_201_20recommended_20configuring_20project_20with_20vcpkg_20toolchain_20and_20registry_20support_0',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]],
  ['option_202_20configuring_20project_20with_20vcpkg_20toolchain_20and_20no_20registry_20support_1',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]]
];
