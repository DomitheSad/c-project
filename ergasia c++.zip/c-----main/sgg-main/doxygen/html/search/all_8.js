var searchData=
[
  ['gcc_0',['GCC',['../page_building_sgg.html#building_sgg_linux_gcc',1,'Linux (GCC)'],['../page_building_with_sgg.html#using_sgg_linux',1,'Linux (GCC)']]]
];
