var searchData=
[
  ['vcpkg_0',['CMake (with Vcpkg)',['../page_building_sgg.html#building_sgg_cmake',1,'']]],
  ['vcpkg_20toolchain_20and_20no_20registry_20support_1',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['vcpkg_20toolchain_20and_20registry_20support_2',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]],
  ['visual_20studio_202019_3',['Windows (Visual Studio 2019)',['../page_building_with_sgg.html#using_sgg_windows',1,'']]],
  ['visual_20studio_202019_20msvc_4',['Windows (Visual Studio 2019 - MSVC)',['../page_building_sgg.html#building_sgg_windows_msvc',1,'']]],
  ['visual_20studio_20project_20that_20uses_20sgg_5',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]]
];
