var searchData=
[
  ['setting_20up_20a_20visual_20studio_20project_20that_20uses_20sgg_0',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]],
  ['setup_1',['Window Setup',['../page_simple_app.html#sub_window_setup',1,'']]],
  ['sgg_2',['SGG',['../page_building_sgg.html',1,'Building SGG'],['../page_building_with_sgg.html',1,'Building your Project with SGG'],['../page_building_with_sgg.html#using_sgg_windows_vs',1,'Setting up a Visual Studio project that uses SGG']]],
  ['sgg_20from_20the_20command_20line_3',['Compiling an application that uses SGG from the command line',['../page_building_with_sgg.html#using_sgg_windows_cmd',1,'']]],
  ['simple_20example_4',['A Simple Example',['../page_simple_app.html',1,'']]],
  ['studio_202019_5',['Windows (Visual Studio 2019)',['../page_building_with_sgg.html#using_sgg_windows',1,'']]],
  ['studio_202019_20msvc_6',['Windows (Visual Studio 2019 - MSVC)',['../page_building_sgg.html#building_sgg_windows_msvc',1,'']]],
  ['studio_20project_20that_20uses_20sgg_7',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]],
  ['support_8',['support',['../page_building_sgg.html#autotoc_md0',1,'[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support'],['../page_building_sgg.html#autotoc_md1',1,'[Option 2] Configuring project with vcpkg toolchain and no registry support']]]
];
