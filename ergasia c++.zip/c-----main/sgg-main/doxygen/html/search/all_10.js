var searchData=
[
  ['that_20uses_20sgg_0',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]],
  ['that_20uses_20sgg_20from_20the_20command_20line_1',['Compiling an application that uses SGG from the command line',['../page_building_with_sgg.html#using_sgg_windows_cmd',1,'']]],
  ['the_20command_20line_2',['Compiling an application that uses SGG from the command line',['../page_building_with_sgg.html#using_sgg_windows_cmd',1,'']]],
  ['third_20party_20libraries_3',['Dependencies and Third - Party Libraries',['../index.html#sub_dependencies',1,'']]],
  ['toolchain_20and_20no_20registry_20support_4',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['toolchain_20and_20registry_20support_5',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]]
];
