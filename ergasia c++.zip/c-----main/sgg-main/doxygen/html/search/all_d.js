var searchData=
[
  ['party_20libraries_0',['Dependencies and Third - Party Libraries',['../index.html#sub_dependencies',1,'']]],
  ['project_20that_20uses_20sgg_1',['Setting up a Visual Studio project that uses SGG',['../page_building_with_sgg.html#using_sgg_windows_vs',1,'']]],
  ['project_20with_20sgg_2',['Building your Project with SGG',['../page_building_with_sgg.html',1,'']]],
  ['project_20with_20vcpkg_20toolchain_20and_20no_20registry_20support_3',['[Option 2] Configuring project with vcpkg toolchain and no registry support',['../page_building_sgg.html#autotoc_md1',1,'']]],
  ['project_20with_20vcpkg_20toolchain_20and_20registry_20support_4',['[Option 1 (Recommended)] Configuring project with vcpkg toolchain and registry support',['../page_building_sgg.html#autotoc_md0',1,'']]]
];
