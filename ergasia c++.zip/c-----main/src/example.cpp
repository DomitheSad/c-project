#include "example.h"

std::string Example::greet() const {
    return "Hello from Example!";
}
