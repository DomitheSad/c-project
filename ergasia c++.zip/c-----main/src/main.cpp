#include <iostream>
#include "example.h"

int main() {
    Example ex;
    std::cout << ex.greet() << std::endl;
    return 0;
}
